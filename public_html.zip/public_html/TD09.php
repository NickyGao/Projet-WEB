<html>
<head>   
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <?php
            include_once("./cible.php")
            function extraire($site) {
                $part1=explode("://", $site);
                $part2=explode(".", $part1[1]);
                echo "<table border='1'>";
                echo "<tr>";

                for($i=1 ; $i<=4 ; $i++) {
                    switch($i) {
                        case 1: echo "<th>Protocole<th>";            break;
                        case 2: echo "<th>Nom de la machine<th>";    break;
                        case 3: echo "<th>Organisme<th>";            break;
                        case 4: echo "<th>TLD<th>";                    break;
                    }
                }
                echo "</tr>";

                echo "<tr>";    
                for($j=1 ; $j<=4 ; $j++){
                    switch($j) {
                        case 1: echo "<td>".$part1[0]."<td>"; break;
                        case 2: echo "<td>".$part2[0]."<td>"; break;
                        case 3: echo "<td>".$part2[1]."<td>"; break;
                        case 4: echo "<td>".$part2[2]."<td>"; break;
                    }    
                }
                echo "</tr>";
                echo "</table>";
            }
    
        
    
    extraire("https://www.u-cergy.fr/fr/index.html");
    ?>
</body>
</html> 