<?php
	function jour($var){
		if($var==0){
			setlocale (LC_TIME, 'fr_FR.utf8','fra'); 
			echo (strftime("%A %d %B %Y "));
		}

		else {
	    	echo date("D, F d,Y");
		}
	}
	jour(1);
?>