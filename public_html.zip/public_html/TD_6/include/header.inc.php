<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Les TDs</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="../TD_1/base.css" />
	<style type="text/css">
		ul{
			padding-top : 5px;
			padding-bottom: 5px ;
			text-align : center;
		}

		li{
			text-decoration : none ;
			display : inline;
			margin-left: none;
			padding-left : 0,5em;
			padding-right : 0.5em;
			text-align : center;
			font-size : 25px ;
		}

		.chiffre{
			color:red;
			background-color: silver;
		}
		
		.majuscule{
			color:green;	
			background-color: silver;	
		}

		.minuscule{
			color:blue;
			background-color: silver;		
		}

		td{
			border-color:black;		
		}
		
		h1{
		text-align : center;
		background-color: blue;
		}
		
		h2{
		text-align : center;
		}
		
		body{
			background-color: silver;		
		}
		
	</style>
	
</head>

<body>
	<div><a href="../"><img src="../TD_1/home.png" alt="Accueil" style ="width:50px;height:50px;" /></a></div>
	<div id="nav">
			<h1>TDs</h1>
				<ul>
					<li><a href="../TD_1/index.html">TD1</a></li>
					<li><a href="../TD_3/index.php">TD3</a></li>
					<li><a href="../TD_4/index.php">TD4</a></li>
					<li><a href="../TD_5/index.php">TD5</a></li>
					<li><a href="../TD_6/index.php">TD6</a></li>
				</ul>
	</div>	
	<div><a href="https://www.u-cergy.fr"><img src="../TD_1/logo-ucp.png" alt="Logo Université de Cergy" /></a></div>