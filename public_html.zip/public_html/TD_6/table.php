<?php
	function multi($n){
    	echo "<table border='1'>";
    	echo "<tr><th> X </th>";
    	for ($colonne = 1 ; $colonne <= $n ; $colonne++ ) {
      	echo "<th>".$colonne."</th>";
    	}
    	echo "</tr>";
    	for ($ligne = 1 ; $ligne <= $n ; $ligne++ ) {
        	echo "<tr><th>".$ligne."</th>";
        	for ($colonne = 1 ; $colonne <= $n ; $colonne++ ) {
				echo "<td>".($ligne * $colonne)."</td>";
       	 }
       	 echo "</tr>";
   	 }
   	 echo "</table>";
	}
	multi(10);
?>