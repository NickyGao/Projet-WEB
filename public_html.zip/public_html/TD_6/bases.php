<?php
	function bases($n){
		echo "<table border='1'><tr><th style=\"background-color:blue\">binaire</th><th style=\"background-color:blue\">octal</th><th style=\"background-color:blue\">d&eacute;cimal</th><th style=\"background-color:blue\">hexad&eacute;cimal</th></tr>";
    	for($i = 0 ; $i <= $n ; $i++) {
      	  printf ("<tr><td>%08b</td><td>%02o</td><td>%02d</td><td>%02X</td></tr>", $i, $i, $i, $i);
    	}
    	echo "</table>";
	}
	bases(20);
?>