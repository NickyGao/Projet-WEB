<!doctype html>
<html>
    <head>
        <link href="./style.css" rel="stylesheet" type="text/css" />
        <title>TD05</title>
        <meta charset="utf-8" />
    </head>
    <body>
        <header>
        <h1>TD -05- PHP</h1>
        
        </header>
        <nav>
            <ul>
                <li><a href="../index.html">page d'accueil</a></li>
                <li><a href="phpinfo.php">php information</a></li>
            </ul>
        </nav>


        <section id="ex01">
            <h2>la boucle </h2>
            <ul>
                <?php
                    boucle(20);
                ?>
            </ul>
        </section>  



        <section id="ex02">
            <h2>le temps </h2>
            <?php
                echo'<p>'."il est :".date("j/m/y--h:m:s").'</p>';
            ?>
        </section>

        <section id="ex03">
            <h2>les chiffres hexadécimaux</h2>
            <?php
             echo '<h3>'." les chiffres hexadécimaux de 0 a 15 :".'</h3>';
            echo '<p>';
             for ($i=0; $i <15 ; $i++) { 
                echo dechex($i)."_";

             }
            echo dechex(15).'</p>';
            ?>
        </section>
        <section id="ex04">
            <h2>Tableau de multiplication </h2>
            <table >
                <tbody>
                <?php
                   tableauMult(10,10);
                ?>
               </tbody>
            </table>


        </section>

    </body>

</html>
<?php

function boucle($x)
{
    
    for($i=0;$i<=$x;$i++)
    {
        echo '<li>';
        echo "hello numéro".$i;
        echo '</li>' ;
    }
   
}

function tableauMult($x,$y){
      for ($i=0; $i <=$x ; $i++) {
            echo '<tr>';
            for ($j=0; $j <=$y ; $j++) { 
               if($i==0 && $j == 0){
                    echo '<th>'."X".'</th>';
                }
                elseif ($i==0 && $j!=0) {
                    echo('<th>'.$j.'</th>');
                }
                elseif ($j==0 && $i!=0) {
                    echo('<th>'.$i.'</th>');
                }
                else
                    echo('<td>'.$i*$j.'</td>');
                }
        echo '</tr>';

        }
}
?>