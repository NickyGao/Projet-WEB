<!doctype html >
<html>
    <head>
        <title>TD05</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <section>
            <p><a href="./td05.php">aller a Td05</a></p>                    
        </section>
        <section>
            <?php
                phpinfo();
            ?>
        </section>
    </body>

</html>
