<?php
/* lecture du fichier */
$fichier = fopen("./Compteur.txt","r+");
$visites = fgets($fichier,255);
$visites++;
fclose($fichier);

/* écriture du fichier */
$fichier=fopen("./Compteur.txt","w");
fwrite($fichier,$visites);
fclose($fichier);
echo "<font color=\"black\"><b>",$visites," fois</b></font>";
?>