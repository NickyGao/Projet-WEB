<!DOCTYPE html>
<html>
    
    <head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>PHP</title>
        <meta name="description" content="An interactive getting started guide for Brackets.">
        <link rel="stylesheet" href="../page-simple/style.css">
        
    </head>
    
        <body>
            
            <h1>Exercices PhP</h1>
            <h2>Exo 1</h2>
            
            <?php
                
                    for($i=0;$i<21;$i++)
                    {
                        echo "hello numéro ",$i;
                        echo "<br/>";
                    }
                    
                
            ?>
            <h2>Exo 2</h2>
            <?php
                echo date("Y/m/d H:i:s"). substr((string)microtime(), 1, 6);
            ?>
            <h2>Exo 3</h2>
            <?php
            for($i=0;$i<16;$i++)
                    {
                        echo dechex ( $i ),",";
                        
                    }
                echo "<br/>";
                echo "1,2,3,4,5,6,7,8,9,A,B,C,D,E,F";
            ?>
            
            <h2>Exo 4</h2>
            <?php
                echo "<table border=\"1\">";

        for ($r =0; $r < 11; $r++){
         echo'<tr>';
            if ($r == 0)
                echo '<td>' ."X".'</td>';
            else
                echo '<td>' .$r.'</td>';

            for ($c = 1; $c < 11; $c++)
            {
                if ($r == 0)
                    echo '<td>' .$c.'</td>';
                else
                    echo '<td>' .$c*$r.'</td>';
            }
                
           echo '</tr>'; 

        }

  echo"</table>";
            ?>
            <h2>Exo 5</h2>
            <?php
                echo "0x41" , "=",hexdec ("0x41") , "=", chr (0x41);
           
                echo "<br/>";
            
                echo "0x",dechex(ord("+")), "=", ord("+"), "=", "+";
            ?>
            <h2>Exo 6</h2>
            <?php
                echo "<table border=\"1\">";

        for ($l =0; $l < 11; $l++){
         echo'<tr>';
            if ($l == 0)
                echo '<td>' ."X".'</td>';
            else
                echo '<td>' .$l.'</td>';

            for ($c = 1; $c < 11; $c++)
            {
                if ($r == 0)
                    echo '<td>' .$c.'</td>';
                else
                    echo '<td>' .$c*$l.'</td>';
            }
                
           echo '</tr>'; 

        }

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  echo"</table>";
            ?>
            <h2>Exo 7</h2>
            
            
            
            
        </body>
</html>