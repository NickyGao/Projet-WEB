<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Informations générales sur l'université de Cergy pontoise </title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>

<body>
<p>
<?php
    $trouver=true;
    if(isset($_POST['mot'])){
        if(empty($_POST['mot'])){
            echo('erreur <br>');
        }
        else{
            $mot=$_POST['mot'];  
             
            $f=fopen('etablissements_denseignement_superieur.csv','r');
            if($f){
 
                while($ligne=fgets($f)){
                    $l=explode(';',$ligne);
                    $recherche=$l[3];
                        
                    if($mot==$recherche){
                        $p=0;
                        
                        while($p<26){
                            if($p<25){
                                echo $l[$p];
                                echo('<br>');
                                $p++;
                            }
                            else {
                                echo '<a href="'.$l[$p].'">'.$l[$p].'</a>';
      
                                $p++;
                            
                            }
                        }
                        $trouver=false;
                    }
                }
                if($trouver){
                    echo("Aucun élément trouvé!");
                }
                fclose($f);
            }
        }
    }
?>
</p>
<p><a href="./index.html">Quitter</a></p>
</body>
</html>