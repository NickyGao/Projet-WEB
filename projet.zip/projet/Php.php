<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Informations générales sur l'université de Cergy pontoise </title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>

<?php
$_POST['Recherche'];
$_POST['pseudo'];
$fop = fopen('etablissements_denseignement_superieur.csv', 'r');
if($fop === false)
{
   // Ouverture du fichier échouée
}
else
{
?>
<table>
<?php
   $delimiter = ';'; // Ton séparateur de cellules
   while(($a = fgetcsv($fop, 0, $delimiter)) !== false) // Récupération d'une ligne
   {
?>
   <tr>
<?php
      foreach($a as $val) // Parcours en boucle des cellules de la ligne
      {
?>
      <td><?php echo $val; ?></td>
<?php
      }
?>
   </tr>
<?php
   }
   fclose($fop);
?>
</table>
<?php
}
?>
    </html>