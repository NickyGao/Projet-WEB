<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Informations générales sur l'université de Cergy pontoise </title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>
</html>